** Hii user 🤙👋 **

Selamat datang di **SHOTA BASED!**
Ini adalah base atau dasaran script bot WhatsApp, yang di buat dan di kembangkan oleh Jarr, dibuat untuk kalian yang ingin membuat script sendiri 🗿

** Jangan lupa follow **
› https://whatsapp.com/channel/0029VbBoflt4dTnNWXV4zC09
› https://whatsapp.com/channel/0029VbBbVB4GufJ0FxE3Yf1Z

** Contacts me **
› t.me/jarroffc2

** Info Base! **
  • Running script di panel peterodactyl (rekomendasi)
  • Gunakan versi Nodejs 20+
  • Sudah support ESM
  • Sudah pake plugins full anjai

**Thanks To**
  • Allah (Tuhanku)
  • Orang tua (Support utama)
  • Keluarga 
  • Creator (Jarr)
  • All creator script 
  • ChatGPT & Gemini (Pahlawan tanpa tanda jasa 🗿)
  
** NOTE :**
*Silahkan gunakan base ini sesuka kalian namun tolong nama Creator utama jangn di hapus, bukan buat validasi atau apa cuma hargain aja🙏*

Btw ini base versi gratis jadi jangan di jual cuy!!🗿
Oh iya gw juga ada base yang berbayar kalo minat langsung aja chat https://wa.me/6285185011474

Sorry klo README.md nya berantakan bingung isinya nya gw 

Gitu aja dari gw enjoy ngoding ;⁠)